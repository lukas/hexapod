Rounded sensor foot with 20 mm cylinder — main / v4
Selection: Full build; all printable STLs.
Extract the ZIP and import the STL files into Bambu Studio. Set copies using quantities.csv or each filename qty suffix.
Each STL is the original asset geometry; assembly positions are not baked into it. Select material, orientation and print settings in your slicer.
Quantities describe all selected instances in the source scene.
Compared STL triangle geometry and quantities with v3; placement, STL header and facet-order changes do not require reprinting.
workflow.json is stored with this revision; this does not verify physical installation.
This is a design export, not a record of what is physically installed.
